# 上传浅绿色和红色渐变主题网站到GitHub指南

## 项目文件列表

需要上传到GitHub仓库 `https://github.com/xiaoruirui170/ruibao` 的文件：

### 新创建的文件（主题版本）
- `green-red-theme.html` - 浅绿色和红色渐变主题的主页面
- `css/green-red-theme.css` - 主题样式文件
- `README-green-red-theme.md` - 主题说明文档

### 原有文件（保持原样）
- `index.html` - 原版网站
- `css/style.css` - 原版样式
- `js/` 目录下的所有JavaScript文件
- `README.md` - 原版说明文档

## 上传方法

### 方法一：使用GitHub网页界面（推荐）
1. 访问 https://github.com/xiaoruirui170/ruibao
2. 点击 "Add file" → "Upload files"
3. 将以下文件拖拽到上传区域：
   - `green-red-theme.html`
   - `css/green-red-theme.css`
   - `README-green-red-theme.md`
4. 添加提交信息，例如："添加浅绿色和红色渐变主题版本"
5. 点击 "Commit changes"

### 方法二：使用Git命令行（如果已安装Git）
```bash
# 克隆仓库
git clone https://github.com/xiaoruirui170/ruibao.git

# 进入目录
cd ruibao

# 复制文件到仓库目录
# 将本地的所有文件复制到克隆的仓库目录中

# 添加文件到Git
git add .

# 提交更改
git commit -m "添加浅绿色和红色渐变主题版本"

# 推送到GitHub
git push origin main
```

## 访问方式

上传后，可以通过以下URL访问：

- **原版网站**: `https://xiaoruirui170.github.io/ruibao/index.html`
- **新主题网站**: `https://xiaoruirui170.github.io/ruibao/green-red-theme.html`

## 文件说明

### green-red-theme.html
- 使用浅绿色和红色渐变主题
- 图表说明面板位于图表上方
- 简洁的标题和页脚文本

### css/green-red-theme.css
- 完整的渐变主题样式
- 响应式设计
- 现代化的UI效果

### README-green-red-theme.md
- 详细的使用说明
- 主题特色介绍
- 技术栈说明

## 注意事项

1. 确保GitHub Pages功能已启用
2. 如果使用自定义域名，需要相应配置
3. 建议先测试本地功能再上传